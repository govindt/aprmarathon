// Encrypt.java  Sybase Product Support group,  12/21/98
//  Copyright (c) 1997, Sybase., Emeryville, CA 94608
//                      All Rights Reserved
//
//  TITLE: Encrypt.java
//
//  START-HISTORY:
//
//    21 Dec 98  edit 0 - Maria Chavez Cantu
//               Initial coding.
//
//  END-HISTORY
//
//

package sample2;
import java.io.*;
import java.sql.*;
import java.util.*;

/**
 * Encrypt class demonstrates how to use the SSL encryption with jConnect
 * by utilizing a custom socket implementation of javax.net.SSLSocket, 
 * and javax.net.SSLSocketFactory.
 *
 * <P> NOTE: In order to run a implementation of javax.net.SSLSocket
 * <UL> 
 *     <LI> javax.net.* classes must be in your CLASSPATH. You may obtain 
 *          these from the JavaWebServer, and other Java products.
 *     <LI> set LD_LIBRARY_PATH to the location of libsafe.o. This library
 *          file can be found along with the javax.net.* classes
 *     <LI> The SSLSocket can only communicate to a ServerSocket that speaks
 *          SSL and has common cipher suites enabled. Currently the only 
 *          ServerSocket that a Sybase client can communicate with is Jaguar.
 * 
 *          <BR> Therefore, you will not be able to run this sample, unless 
 *          you configure it for your specific cipher suites, and pass in the
 *          url to a SSL Server Socket at connection time.
 * </UL>
 *
 * <P>Encrypt.java must be invoked with the parameters:
 * -U username<br>
 * -P password<br>
 * -D debuglibraries<br>
 * -S server<p>
 *
 *  @see Sample
 */
public class Encrypt extends Sample
{

    /**
	 * Language query
	 */
    public static final String QUERY = "object32";

    /**
	 * constructor
	 */
    Encrypt()
    {
        super();
    }

    /**
	 * Set connection properties
	 * @param cmdline - commandline args object
	 */
    public void addMoreProps(CommandLine cmdline)
    {
        // set the SYBSOCKET_FACTORY property
        cmdline._props.put("SYBSOCKET_FACTORY", 
            "sample2.MySSLSocketFactory");


        // set the cipher suites
        cmdline._props.put("CIPHER_SUITES_1", 
            "SSL_DH_anon_EXPORT_WITH_RC4_40_MD5");
        /*	
		// depending on the cipher suite set on the server
		// side, you could set as many as you would like
        cmdline._props.put("CIPHER_SUITES_2", 
			"SSL_DH_DSS_EXPORT_WITH_DES40_CBC_SHA");
        cmdline._props.put("CIPHER_SUITES_3", 
			"SSL_RSA_EXPORT_WITH_RC2_CBC_40_MD5");
        cmdline._props.put("CIPHER_SUITES_4", 
			"SSL_DH_RSA_EXPORT_WITH_DES40_CBC_SHA");
		*/
    }

    /**
	 * Demonstrate the use of SSL Encryption
     * with a PreparedStatement object
	 */
    public void sampleCode()
    {
        try
        {

            PreparedStatement pstmt = _con.prepareStatement(QUERY);
            output("Executing: " + QUERY + "\n");

            ResultSet rs = pstmt.executeQuery ();
            dispResultSet(rs);

            rs.close();
            pstmt.close();
        }
        catch (SQLException ex)
        {
            displaySQLEx(ex);
        }
    }
}
