// DebugExample.java  Sybase Product Support group,  06/01/97
//  Copyright (c) 1997, Sybase., Emeryville, CA 94608
//                      All Rights Reserved
//
//  TITLE: DebugExample.java
//
//  START-HISTORY:
//
//    01 Jun 97  edit 0 - Lance Andersen.
//               Initial coding.
//
//  END-HISTORY
//
//

package sample2;
import com.sybase.jdbcx.Debug;
import java.io.*;
import java.sql.*;
import java.util.*;

/**
 * DebugExample class   Demonstrates how to use the Debug Class<br>
 *
 * Note:  You must use $JDBC_HOME/devclasses
 *
 * <P>DebugExample may be invoked with the optional parameters:<br>
 * -U username<br>
 * -P password<br>
 * -D debuglibraries<br>
 * -S server<p>
 *
 *  @see Sample
 */
public class DebugExample extends Sample
{

    DebugExample()
    {
        super();
    }

    public void sampleCode()
    {

        Debug debug = _sybDriver.getDebug();

        String traceOutputFile = "." + System.getProperty("file.separator")
            + "Debug.trace";

        // Trace specific classes.  Could have specified "ALL" to trace
        // all classes
        String debugLibs = "SybConnection:SybStatement:Debug:STATIC";
        String selectQuery = "select pub_id, title_id, title from titles";

        try
        {

            // Open a PrintStream where to redirect the trace output
            PrintStream debugLogStream = null;
            if(!_anApplet)
            {
                debugLogStream = new PrintStream(new
                    FileOutputStream(traceOutputFile));
            }
            else
            {
                //since can't create a file over the wire, 
                //simply print to standard out - Java Console
                error("Since you are running as an applet, \n"
                    +" A log file could not be created, so \n"
                    +" any log output will be sent to stdout.\n");
                debugLogStream = System.out;
            }

            // Enable Debug Tracing
            debug.debug(true, debugLibs, debugLogStream);

            // Write a message to the Debug PrintStream
            debug.println( "*** Calling Connection.createStatement ***");
            Statement stmt = _con.createStatement();
            debug.startTimer(null);
            output("Executing: " + selectQuery + "\n");
            ResultSet rs = stmt.executeQuery (selectQuery);
            debug.stopTimer(null,"*****executeQuery snapshot");
            dispResultSet(rs);

            // Demonstrate the use of assert()

            debug.assert(null, false,"Test of debug.assert");
            stmt.close();
            rs.close();
        }
        catch (SQLException ex)
        {
            displaySQLEx(ex);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
